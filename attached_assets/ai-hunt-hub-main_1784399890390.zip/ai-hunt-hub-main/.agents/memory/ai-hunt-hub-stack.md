---
name: AI Hunt Hub Stack Decisions
description: Key architectural and integration choices for the AI Hunt Hub project
---

**Stack**: React + Vite (ai-hunt-hub artifact at /), Express API server (api-server artifact), PostgreSQL + Drizzle ORM, Clerk auth, React Query.

**DB seed**: Run `pnpm --filter @workspace/db run seed` — seeds 12 categories, 12 tools, 4 blog posts, 5 news articles. Tool status must be 'approved' or 'featured' for public visibility.

**Clerk**: Frontend uses publishableKeyFromHost from @clerk/react/internal; proxy at CLERK_PROXY_PATH; clerkMiddleware on Express uses publishableKeyFromHost from @clerk/shared/keys.

**Route pattern**: All API routes under /api/* in Express. Bookmark check endpoint (/bookmarks/check/:toolId) must NOT use requireAuth — returns { bookmarked: false } for unauthenticated users.

**Schema**: tools table has text arrays (features, pros, cons, platforms, integrations, tags, screenshots). Category names join via enrichToolsWithCategory() in routes — tools don't store categoryName directly.

**Why**: Kept tags denormalized in tools.tags (text array) to avoid extra join complexity. Tags endpoint computes counts dynamically from tools table.
