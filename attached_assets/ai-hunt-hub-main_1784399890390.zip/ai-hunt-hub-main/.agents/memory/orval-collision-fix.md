---
name: Orval TS2308 Collision Fix
description: How to avoid duplicate export name errors when using Orval codegen
---

**Problem**: Orval v8 generates both a Zod schema (in api.ts) AND a TypeScript type (in types/) named {OperationId}Params for operations with path params. When both are re-exported from index.ts via export *, TS2308 collision occurs.

**Affected pattern**: Any operation that has BOTH path params AND query params generates two identically-named exports.

**Fix**: Remove query params from operations that already have path params. The server uses hardcoded defaults for limit/pagination. Applied to getRelatedTools (removed limit query param) and listReviews (removed page/limit query params).

**Why**: Orval naming convention for path params and query params both produce {Op}Params, causing the collision. Restructuring the spec to avoid combining both param types on the same operation is the cleanest fix.
