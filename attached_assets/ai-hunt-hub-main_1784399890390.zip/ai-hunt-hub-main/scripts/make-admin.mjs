/**
 * Run this in the Replit Shell to make yourself admin:
 *   node scripts/make-admin.mjs
 *
 * It lists all signed-up users and promotes the first one (or a specified email).
 */

import pg from "pg";

const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL });

const email = process.argv[2]; // optional: node make-admin.mjs you@email.com

const { rows: users } = await pool.query("SELECT id, clerk_user_id, email, name, role FROM users ORDER BY created_at LIMIT 10");

if (users.length === 0) {
  console.log("\n  No users found yet.\n  Sign in to your app at least once first, then run this script again.\n");
  process.exit(0);
}

console.log("\nExisting users:");
users.forEach((u, i) => console.log(`  ${i + 1}. ${u.name || "(no name yet)"} | ${u.email || "(no email)"} | ${u.clerk_user_id} | role: ${u.role}`));

let target = email
  ? users.find((u) => u.email === email)
  : users[0];

if (!target && email) {
  console.log(`\n  User with email "${email}" not found. Promoting user #1 instead.`);
  target = users[0];
}

const { rowCount } = await pool.query("UPDATE users SET role = 'admin' WHERE id = $1", [target.id]);

if (rowCount > 0) {
  console.log(`\n  SUCCESS! "${target.name || target.clerk_user_id}" is now an admin.\n  Refresh the app and go to /admin to see the admin dashboard.\n`);
} else {
  console.log("\n  Something went wrong. Try again.");
}

await pool.end();
